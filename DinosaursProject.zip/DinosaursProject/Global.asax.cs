﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;

namespace DinosaursProject
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            Application["UsersLoggedIn"] = 0;
            Application["A1"] = 0; //answer1
            Application["A2"] = 0;
            Application["A3"] = 0; 
            Application["A4"] = 0; 
            Application["A5"] = 0; 
        }
        void Application_End(object sender, EventArgs e)
        {
            // Code that runs on application end
        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs on application has an error

        }
        void Session_Start(object sender, EventArgs e)
        {
            Session["UserName"] = "Guest";
            Session["Admin"] = "NO";
            Session["IsConnected"] = "NO";
            Session["Votes"] = 5;

        }
        void Session_End(object sender, EventArgs e)
        {
            Session["UserName"] = "Guest";
            Session["IsConnected"] = "NO";  
            Session["Admin"] = "NO";
            Session["Votes"] = 5;
        }
    }
}