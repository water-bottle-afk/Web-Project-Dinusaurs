﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class Login : System.Web.UI.Page
    {
        public string st = "";
        public string sqlMsg = "";
        public string msg = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["IsConnected"].ToString() == "YES")
            {
                Response.Redirect("TRex.aspx");
            }

            if (Request.Form["submit"] != null)
            {
                string fileName = "Database.mdf";
                string tableName = "tblUsers";

                string userName = Request.Form["userName"];
                string password = Request.Form["Password"];

                //in green - not safe sql

                //string sqlLogin = $"SELECT * FROM {tableName} WHERE UserName = '{userName}' AND Password = '{password}'";
                string safeSQL = $"SELECT * FROM {tableName} WHERE UserName = @UserName AND Password = @Password";

                string[] parameters = { userName, password };
                //DataTable table = DBHelper.ExecuteDataTable(fileName, sqlLogin);
                DataTable table = DBHelper.Login(fileName, safeSQL, parameters);

                int length = table.Rows.Count;

                msg = safeSQL;
                if (length == 0) //length != 1
                {
                    msg = "User Was Not Found";
                }
                else
                {
                    Session["UserName"] = table.Rows[0]["UserName"];
                    Session["IsConnected"] = "YES";

                    string safeAdminSQL = $"SELECT * FROM AdminTbl WHERE UserName = @UserName AND Password = @Password";
                    DataTable tableForAdmin = DBHelper.Login(fileName, safeAdminSQL, parameters);
                    int lengthAdmin = tableForAdmin.Rows.Count;

                    if (lengthAdmin == 1)
                    {
                        Session["Admin"] = "YES";
                    }
                    else
                    {
                        Session["Admin"] = "NO";
                    }

                    Application.Lock();
                    Application["UsersLoggedIn"] = (int) Application["UsersLoggedIn"] + 1;
                    Application.UnLock();

                    Response.Redirect("Dinosaurs.aspx");
                }

            }
        }
    }
}