﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class DeleteUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string fileName = "Database.mdf";
            string tableName = "tblUsers";
            string hobbyTableName = "HobbiesTbl";


            string username = Request.QueryString["Username"];
            string page = Request.QueryString["page"];

            if (username == null || page == null)
            {
                Response.Redirect("TRex.aspx");
            }

            if (page == "UsersTable" || page == "HasAINUserName" ||
                page == "LivesInNYAndBornedAt2000" || page == "PrefixIs050Or052")
            {
                
                string sqlDeleteUser = $"DELETE FROM {tableName} WHERE UserName = '{username}';";
                string sqlDeleteHobby = $"DELETE FROM {hobbyTableName} WHERE UserName = '{username}';";
                string sqlDeleteAdmin = $"DELETE FROM AdminTbl WHERE UserName = '{username}';";

                DBHelper.DoQuery(fileName, sqlDeleteHobby);
                DBHelper.DoQuery(fileName, sqlDeleteUser);
                DBHelper.DoQuery(fileName, sqlDeleteAdmin);


                //if the Admin deletes himself, than he should be disconnected
                //the same code from the logout.cs
                if (username == Session["UserName"].ToString())
                {
                    Response.Cache.SetExpires(DateTime.Now.AddMinutes(-1));
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.Cache.SetNoStore();
                    Response.Clear();


                    Session.Clear();
                    Session.RemoveAll();
                    Session.Abandon();

                    Response.Redirect("Dinosaurs.aspx");
                }
            }

            if (page == "ShowHobbies")
            {
                int hobbyId = Convert.ToInt32(Request.QueryString["hobby"].ToString());
                string sqlDeleteHobby = $"DELETE FROM {hobbyTableName} WHERE UserName" +
                    $" = '{username}' AND HobbyId = {hobbyId};";

                DBHelper.DoQuery(fileName, sqlDeleteHobby);

            }

            string goToPage = page + ".aspx";
            Response.Redirect(goToPage);
        }
    }
}