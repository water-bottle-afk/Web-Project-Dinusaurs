﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class ShowHobbies : System.Web.UI.Page
    {
        public string tblUsers = "";
        public string st = "";
        public string msg = "";
        public string sqlSelect = "";
        //{DBHelper.DB_USER_TABLE};
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Admin"].ToString() != "YES")
            {
                Response.Redirect("TRex.aspx");
            }
            string fileName = "Database.mdf";

            sqlSelect = $"SELECT HobbiesTbl.UserName, HobbiesTbl.HobbyId, Hobbies.HobbyName" +
                $" FROM HobbiesTbl INNER JOIN Hobbies ON Hobbies.HobbyId = HobbiesTbl.HobbyId;";
            DataTable table = DBHelper.ExecuteDataTable(fileName, sqlSelect);

            string sqlSelectHobby = $"SELECT * FROM HobbiesTbl;";
            DataTable tableHobby = DBHelper.ExecuteDataTable(fileName, sqlSelectHobby);

            int length = table.Rows.Count;
            if (length == 0)
            {
                msg = "NO USERS";
            }
            else
            {
                st += "<tr>";
                st += "<th>User Name</th>";
                st += "<th>Hobby Name</th>";
                st += "<th>Delete Hobby</th>";

                st += "</tr>";

            }

            for (int i = 0; i < length; i++)
            {
                st += "<tr>";

                st += $"<td>{table.Rows[i]["UserName"]}</td>";
                st += $"<td>{table.Rows[i]["HobbyName"]}</td>";
                string username = table.Rows[i]["UserName"].ToString();
                string page = "ShowHobbies";
                int hobby = Convert.ToInt32((tableHobby.Rows[i]["HobbyId"].ToString()));

                st += $"<td><a href = 'DeleteUser.aspx?Username={username}&page={page}&hobby={hobby}'" +
                    $" class='deleteUser'>[DELETE]</a></td>";


                st += "</tr>";
            }

            msg = $"The total of hobbies is {length}";
        }
    }
}