﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class Survey : System.Web.UI.Page
    {
        public string msg = "";
        public string usersLeft;
        public double a1;
        public double a2;
        public double a3;
        public double a4;
        public double a5;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["IsConnected"].ToString() == "NO")
            {
                Response.Redirect("TRex.aspx");
            }

            int votes = (int)(Session["Votes"]);

            int[] s = new int[5];

            a1 = 0;
            a2 =0;
            a3 = 0;
            a4 = 0;
            a5 = 0;
            if (Request.Form["submit"] != null && Request.Form["answer"] != null && votes > 0)
            {
                int ans = int.Parse(Request.Form["answer"].ToString());
                votes = votes - 1;

                Session["Votes"] = (int)(Session["votes"]) - 1;

                if (ans == 1)
                {
                    Application["A1"] = (int)Application["A1"] + 1;
                }
                if (ans == 2)
                {
                    Application["A2"] = (int)Application["A2"] + 1;
                }
                if (ans == 3)
                {
                    Application["A3"] = (int)Application["A3"] + 1;
                }
                if (ans == 4)
                {
                    Application["A4"] = (int)Application["A4"] + 1;
                }
                if (ans == 5)
                {
                    Application["A5"] = (int)Application["A5"] + 1;
                }
            }
                s = new int[5];
                s[0] = (int)Application["A1"];
                s[1] = (int)Application["A2"];
                s[2] = (int)Application["A3"];
                s[3] = (int)Application["A4"];
                s[4] = (int)Application["A5"];

                int sum = s[0] + s[1] + s[2] + s[3] + s[4];
                double[]w = new double[5];
                for (int i = 0; i < w.Length; i++)
                {
                    if (sum == 0)
                    {
                        w[i] = 0;
                    }
                    else
                    {
                        w[i] = (s[i] * 10 / (double)(sum)) * 50;
                    }
                }
                a1 = w[0];
                a2 = w[1];
                a3 = w[2];
                a4 = w[3];
                a5 = w[4];

                msg = $"a1 = {(int)Application["A1"]} | a2 = {(int)Application["A2"]} | a3={(int)Application["A3"]} | a4={(int)Application["A4"]} | a5= {(int)Application["A5"]}";
            if (votes > 0)
            {
                usersLeft = $"{votes} votes left for you!";
            }
            else
            {
                usersLeft = "NO MORE VOTES LEFT";
            }
        }
    }
}