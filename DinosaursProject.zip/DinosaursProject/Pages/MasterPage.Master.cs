﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {
        public string welcomeClass="class"; //doesn't matter
        public string clockClass="class"; //doesn't matter

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["isConnected"].ToString() == "YES")
            {
                welcomeClass = "welcomeWhenUserIsConnected";
                clockClass = "";
            }
            else
            {
                welcomeClass = "welcome";
                clockClass = "Invisable";
            }



            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Cache-Control", "no-store");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();
            Response.AppendHeader("pragma", "no-cache");
        }
    }
}