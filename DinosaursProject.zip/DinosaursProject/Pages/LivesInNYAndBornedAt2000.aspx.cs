﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class LivesInNYAndBornedAt2000 : System.Web.UI.Page
    {
        public string tblUsers = "";
        public string st = "";
        public string msg = "";
        public string sqlSelect = "";
        //{DBHelper.DB_USER_TABLE};
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Admin"].ToString() != "YES")
            {
                Response.Redirect("TRex.aspx");
            }
            string fileName = "Database.mdf";

            sqlSelect = $"SELECT tblUsers.*, Prefixes.Prefix, Cities.CityName FROM" +
                $" Prefixes INNER JOIN (Cities INNER JOIN tblUsers ON Cities.Id" +
                $" = tblUsers.CityId) ON Prefixes.Id = tblUsers.PrefixId WHERE (tblUsers.CityId = 6)" +
                $" AND (tblUsers.YearBorn = 2000)";

            DataTable table = DBHelper.ExecuteDataTable(fileName, sqlSelect);


            int length = table.Rows.Count;
            if (length == 0)
            {
                msg = "NO USERS";
            }
            else
            {
                st += "<tr>";
                st += "<th>User Name</th>";
                st += "<th>City</th>";
                st += "<th>Year Born</th>";
                st += "<th>Email</th>";
                st += "<th>Password</th>";
                st += "<th>Delete User</th>";

                st += "</tr>";

            }

            for (int i = 0; i < length; i++)
            {
                st += "<tr>";

                st += $"<td>{table.Rows[i]["UserName"]}</td>";
                st += $"<td>{table.Rows[i]["CityName"]}</td>";
                st += $"<td>{table.Rows[i]["YearBorn"]}</td>";
                st += $"<td>{table.Rows[i]["Email"]}</td>";
                st += $"<td>{table.Rows[i]["Password"]}</td>";
                string username = table.Rows[i]["UserName"].ToString();
                string page = "LivesInNYAndBornedAt2000";

                st += $"<td><a href = 'DeleteUser.aspx?Username={username}&page={page}' class='deleteUser'>[DELETE]</a></td>";

                st += "</tr>";
            }

            msg = $"The amount of users is {length}";
        }
    }
}