﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class Update : System.Web.UI.Page
    {
        public string sqlMsg = "";
        public string msg = "";
        public string st = "";

        public string sqlSelect = "";
        public string sqlUpdate = "";


        public string userName = "";
        public string password = "";
        public string firstName = "";
        public string lastName = "";
        public string Email = "";
        public string gender = "";
        public string hobbies = "";
        public int yearBorn;
        public string phone = "";
        public int prefix;
        public int city;


        //1 for existance, 0 for no
        public int hob1;
        public int hob2;
        public int hob3;
        public int hob4;



        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["IsConnected"].ToString() == "NO")
            {
                Response.Redirect("TRex.aspx");
            }
            string fileName = "Database.mdf";
            string tableName = "tblUsers";

            userName = Session["UserName"].ToString();

            sqlSelect = $"SELECT * FROM {tableName} WHERE UserName = '{Session["UserName"].ToString()}'";

            DataTable table = DBHelper.ExecuteDataTable(fileName, sqlSelect);

            password = table.Rows[0]["Password"].ToString();
            firstName = table.Rows[0]["FirstName"].ToString();
            lastName = table.Rows[0]["LastName"].ToString();
            Email = table.Rows[0]["Email"].ToString();
            prefix = Convert.ToInt32(table.Rows[0]["prefixId"]);
            phone = table.Rows[0]["Phone"].ToString();
            city = Convert.ToInt32(table.Rows[0]["CityId"]);
            gender = table.Rows[0]["Gender"].ToString();
            yearBorn = Convert.ToInt16(table.Rows[0]["YearBorn"]);

            string hobbyTableName = "HobbiesTbl";
            string sqlSelectHobby = $"SELECT * FROM {hobbyTableName} WHERE UserName = '{userName}'";
            DataTable hobbyTable = DBHelper.ExecuteDataTable(fileName, sqlSelectHobby);

            for (int i = 0; i < hobbyTable.Rows.Count; i++)
            {
                if (Convert.ToInt32(hobbyTable.Rows[i]["HobbyId"]) == 1)
                {
                    hob1 = 1;
                }
                if (Convert.ToInt32(hobbyTable.Rows[i]["HobbyId"]) == 2)
                {
                    hob2 = 1;
                }
                if (Convert.ToInt32(hobbyTable.Rows[i]["HobbyId"]) == 3)
                {
                    hob3 = 1;
                }
                if (Convert.ToInt32(hobbyTable.Rows[i]["HobbyId"]) == 4)
                {
                    hob4 = 1;
                }
            }
            if (this.IsPostBack)
            {
                password = Request.Form["Password"];
                firstName = Request.Form["firstName"];
                lastName = Request.Form["lastName"];
                Email = Request.Form["Email"];
                gender = Request.Form["gender"];
                hobbies = Request.Form["hobbies"].ToString();
                yearBorn = int.Parse(Request.Form["yearBorn"]);
                phone = Request.Form["phone"];
                prefix = int.Parse(Request.Form["prefix"]);
                city = int.Parse(Request.Form["cities"]);


                if (Session["Admin"].ToString() == "YES")
                {
                    string sqlUpdateAdmin = $"UPDATE AdminTbl " +
                        $"SET Password = '{password}'" +
                        $"WHERE UserName = '{Session["UserName"].ToString()}';";

                    DBHelper.DoQuery(fileName, sqlUpdateAdmin);

                }

                sqlUpdate = $"UPDATE {tableName} " +
                $"SET Email = '{Email}', " +
                $"FirstName = '{firstName}', " +
                $"LastName = '{lastName}', " +
                $"PrefixId = {prefix}, " +
                $"Phone = '{phone}', " +
                $"CityId = {city}, " +
                $"YearBorn = {yearBorn}, " +
                $"Gender = '{gender}', " +
                $"Password = '{password}' " +
                $"WHERE UserName = '{Session["UserName"].ToString()}';";

                sqlMsg += sqlUpdate + '\n';

                DBHelper.DoQuery(fileName, sqlUpdate);

                string sqlDeleteHobbies = $"DELETE FROM {hobbyTableName} WHERE UserName = '{Session["UserName"].ToString()}'";

                sqlMsg += sqlDeleteHobbies + '\n';


                DBHelper.DoQuery(fileName, sqlDeleteHobbies);

                string[] hobbyIds = hobbies.Split(',');

                foreach (string hobbyId in hobbyIds)
                {
                    string sqlInsertHobby = $"INSERT INTO HobbiesTbl (UserName, HobbyId) " +
                                            $"VALUES ('{userName}', {hobbyId.Trim()});";

                    DBHelper.DoQuery(fileName, sqlInsertHobby);

                    sqlMsg += sqlInsertHobby + '\n';

                }
                Session["isConnected"] = "YES";
                
            }
        }
    }
}