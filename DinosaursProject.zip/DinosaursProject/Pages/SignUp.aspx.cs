﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DinosaursProject.Pages
{
    public partial class SignUp : System.Web.UI.Page
    {
        public string st = "";
        public string sqlMsg = "";
        public string msg = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["IsConnected"].ToString() == "YES")
            {
                Response.Redirect("TRex.aspx");
            }
            if (Request.Form["submit"] != null)
            {
                string fileName = "Database.mdf";
                string tableName = "tblUsers";

                string userName = Request.Form["userName"];
                string password = Request.Form["Password"];
                string firstName = Request.Form["firstName"];
                string lastName = Request.Form["lastName"];
                string Email = Request.Form["Email"];
                string gender = Request.Form["gender"];
                string hobbies = Request.Form["hobbies"].ToString();
                string yearBorn = Request.Form["yearBorn"];
                string phone = Request.Form["phone"];
                string prefix = Request.Form["prefix"];
                string city = Request.Form["cities"];


                string sqlInsert = "";
                string ALLsqlInsertHobby = "";


                string sqlSelect = $"SELECT * FROM {tableName} WHERE UserName = '{userName}'";

                if (DBHelper.Find(fileName, sqlSelect))
                {
                    msg = "User Name Has Been Taken";
                    sqlMsg = sqlSelect;
                }
                else
                {
                    sqlInsert = $"INSERT INTO {tableName} " +
                        $"(UserName, Email, FirstName, LastName, PrefixId, Phone, CityId, " +
                        $"YearBorn, Gender, Password) " +
                        $"VALUES ('{userName}', '{Email}', '{firstName}', '{lastName}', {prefix}, '{phone}', " +
                        $"{city}, {yearBorn}, '{gender}', '{password}');";

                    DBHelper.DoQuery(fileName, sqlInsert);

                        //hobbies
                        string[] hobbyIds = hobbies.Split(',');

                        foreach (string hobbyId in hobbyIds)
                        {
                            string sqlInsertHobby = $"INSERT INTO HobbiesTbl (UserName, HobbyId) " +
                                                    $"VALUES ('{userName}', {hobbyId.Trim()});"; //removes the spaces

                            DBHelper.DoQuery(fileName, sqlInsertHobby);
                            ALLsqlInsertHobby += sqlInsertHobby + "\n";
                        }
                    
                    if (hobbies != "")
                    {
                        sqlMsg = sqlInsert + '\n' + ALLsqlInsertHobby;

                    }
                    else
                    {
                        sqlMsg = sqlInsert;
                    }
                    msg = "SUCCESS!";
                }
            }
        }
    }
}