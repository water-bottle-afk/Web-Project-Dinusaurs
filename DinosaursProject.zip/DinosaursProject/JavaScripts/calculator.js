﻿function CheckSum() {
    var count = 0;
    //Sum
    var num1Sum = parseInt(document.getElementById("num1Sum").value);
    var num2Sum = parseInt(document.getElementById("num2Sum").value);
    var answerSum = parseInt(document.getElementById("answerSum").value);

    if ((num1Sum + num2Sum) === answerSum) {
        document.getElementById("msgSum").innerHTML = "Yes!";
        count++;
    } else {
        document.getElementById("msgSum").innerHTML = "No!";
    }

    //Sub
    var num1Sub = parseInt(document.getElementById("num1Sub").value);
    var num2Sub = parseInt(document.getElementById("num2Sub").value);
    var answerSub = parseInt(document.getElementById("answerSub").value);

    if (num1Sub - num2Sub === answerSub) {
        document.getElementById("msgSub").innerHTML = "Yes!";
        count++;
    } else {
        document.getElementById("msgSub").innerHTML = "No!";
    }

    //Mult
    var num1Mult = parseInt(document.getElementById("num1Mult").value);
    var num2Mult = parseInt(document.getElementById("num2Mult").value);
    var answerMult = parseInt(document.getElementById("answerMult").value);

    if (num1Mult * num2Mult === answerMult) {
        document.getElementById("msgMult").innerHTML = "Yes!";
        count++;
    } else {
        document.getElementById("msgMult").innerHTML = "No!";
    }

    //Div
    var num1Div = parseInt(document.getElementById("num1Div").value);
    var num2Div = parseInt(document.getElementById("num2Div").value);
    var answerDiv = parseInt(document.getElementById("answerDiv").value);

    if (parseInt(num1Div / num2Div) === answerDiv) {
        document.getElementById("msgDiv").innerHTML = "Yes!";
        count++;
    } else {
        document.getElementById("msgDiv").innerHTML = "No!";
    }

    //Mod
    var num1Mod = parseInt(document.getElementById("num1Mod").value);
    var num2Mod = parseInt(document.getElementById("num2Mod").value);
    var answerMod = parseInt(document.getElementById("answerMod").value);

    if (num1Mod % num2Mod === answerMod) {
        document.getElementById("msgMod").innerHTML = "Yes!";
        count++;
    } else {
        document.getElementById("msgMod").innerHTML = "No!";
    }

    document.getElementById("CountAll").innerHTML = "You answered " + count + " Correct Answer(s).";

}

window.onload = function OnPageLoad() {
    refill();
}

function GetNum() {
    var num = parseInt((Math.random() * 10) + 1);
    return num;
}

function refill() {
    num1Sum = GetNum(); num2Sum = GetNum();
    document.getElementById("num1Sum").value = num1Sum;
    document.getElementById("num2Sum").value = num2Sum;
    document.getElementById("answerSum").value = null;
    document.getElementById("msgSum").innerHTML = "";

    //Sub
    num1Sub = GetNum(); num2Sub = GetNum();
    document.getElementById("num1Sub").value = num1Sub;
    document.getElementById("num2Sub").value = num2Sub;
    document.getElementById("answerSub").value = null;
    document.getElementById("msgSub").innerHTML = "";

    //Mult
    num1Mult = GetNum(); num2Mult = GetNum();
    document.getElementById("num1Mult").value = num1Mult;
    document.getElementById("num2Mult").value = num2Mult;
    document.getElementById("answerMult").value = null;
    document.getElementById("msgMult").innerHTML = "";

    //Div
    num1Div = GetNum(); num2Div = GetNum();
    document.getElementById("num1Div").value = num1Div;
    document.getElementById("num2Div").value = num2Div;
    document.getElementById("answerDiv").value = null;
    document.getElementById("msgDiv").innerHTML = "";

    //Mod
    num1Mod = GetNum(); num2Mod = GetNum();
    document.getElementById("num1Mod").value = num1Mod;
    document.getElementById("num2Mod").value = num2Mod;
    document.getElementById("answerMod").value = null;
    document.getElementById("msgMod").innerHTML = "";

    document.getElementById("CountAll").innerHTML = "";

}