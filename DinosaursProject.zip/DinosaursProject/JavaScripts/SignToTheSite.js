﻿function checkFormSignUp() {
    var count = 0;

    //var prefix = document.getElementById("prefix").value;
    //if (prefix == '0') {
    //    document.getElementById("prefixMsg").value = "choose prefix";
    //    document.getElementById("prefixMsg").style.display = "inline";
    //    count++;
    //}
    //else {
    //    document.getElementById("prefixMsg").style.display = "none";
    //}
    

    if (!(userNameCheck())) {
        count++;
    }
    if (!(passwordCheck())) {
        count++;
    }
    if (!(verifyPasswordCheck())) {
        count++;
    }
    if (!(firstNameCheck())) {
        count++;
    }
    if (!(lastNameCheck())) {
        count++;
    }
    if (!(emailCheck())) {
        count++;
    }
    if (!(genderCheck())) {
        count++;
    }
    if (!(hobbiesCheck())) {
        count++;
    }
    if (!(phoneCheck())) {
        count++;
    }
    if (!(prefixCheck())) {
        count++;
    }
    if (!(yearBornCheck())) {
        count++;
    }
    if (!(citiesCheck())) {
        count++;
    }
    //if ((!prefixCheck())) {
    //    count++;
    //}

    if (count != 0) {
        return false;
    }
    return true;
}

function checkFormLogin() {
    var count = 0;

    

    if (!(userNameCheck())) {
        count++;
    }
    if (!(passwordCheck())) {
        count++;
    }

    if (count != 0) {
        return false;
    }
    return true;
}



//NADAV
function userNameCheck() {
    var userName = document.getElementById("userName").value;
    var size = userName.length;
    var msg = "";

    if (size < 6 || size > 30) {
        msg = "Username is too long or too short!";
    } else if (hasQuotes(userName)) {
        msg = "Username can NOT contain ' sign or \" sign!";
    } else if (isValidChars(userName)) {
        msg = "Username must only have valid chars!";
    } else if (hasHebrewChars(userName)) {
        msg = "Username must not have Hebrew letters!";
    }
    if (msg != "") {
        document.getElementById("userNameMsg").value = msg;
        document.getElementById("userNameMsg").style.display = "inline";
        return false;
    } else {
        document.getElementById("userNameMsg").value = "";
        document.getElementById("userNameMsg").style.display = "none";
    }
    return true;
}

function passwordCheck() {
    var password = document.getElementById("password").value;
    var size = password.length;
    var msg = "";

    if (size < 6 || size > 30) {
        msg = "Password is too long or too short!";
    }
    else if (isValidChars(password)) {
        msg = "Password must only have valid chars!"
    }
    else if (!hasCapitalAndLowercase(password)) {
        msg = "Password must contain at least 1 Uppercase and 1 lowercase letters!"
    }
    else if (!hasDigit(password)) {
        msg = "Password must contain at least 1 digit!"

    }
    if (msg != "") {
        document.getElementById("passwordMsg").value = msg;
        document.getElementById("passwordMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("passwordMsg").value = "";
        document.getElementById("passwordMsg").style.display = "none";
    }
    return true;
}

function verifyPasswordCheck() {
    var password = document.getElementById("password").value;
    var verify = document.getElementById("verifyPassword").value;

    var msg = "";

    var size = password.length;

    if (size < 6 || size > 30) {
        msg = "Password must be full!";
    }

    if (!equals(password, verify)) {
        msg = "The two passwords must be identical!";
    }
    if (msg != "") {
        document.getElementById("verifyPasswordMsg").value = msg;
        document.getElementById("verifyPasswordMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("verifyPasswordMsg").value = "";
        document.getElementById("verifyPasswordMsg").style.display = "none";
    }
    return true;
}


function firstNameCheck() {
    var firstName = document.getElementById("firstName").value;
    var size = firstName.length;
    var msg = "";

    if (size < 2 || size > 30) {
        msg = "First Name is too long or too short!";
    }
    else if (hasQuotes(firstName)) {
        msg = "First Name can NOT contain ' sign or \" sign!";
    }
    else if (isValidChars(firstName)) {
        msg = "First Name must only have valid chars!"
    }
    else if (hasHebrewChars(firstName)) {
        msg = "First Name must not have Hebrew letters!"
    }
    if (msg != "") {
        document.getElementById("firstNameMsg").value = msg;
        document.getElementById("firstNameMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("firstNameMsg").value = "";
        document.getElementById("firstNameMsg").style.display = "none";
    }
    return true;
}

function lastNameCheck() {
    var lastName = document.getElementById("lastName").value;
    var size = lastName.length;
    var msg = "";

    if (size < 2 || size > 30) {
        msg = "Last Name is too long or too short!";
    }
    else if (hasQuotes(lastName)) {
        msg = "Last Name can NOT contain ' sign or \" sign!";
    }
    else if (isValidChars(lastName)) {
        msg = "Last Name must only have valid chars!"
    }
    else if (hasHebrewChars(lastName)) {
        msg = "Last Name must not have Hebrew letters!"
    }
    if (msg != "") {
        document.getElementById("lastNameMsg").value = msg;
        document.getElementById("lastNameMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("lastNameMsg").value = "";
        document.getElementById("lastNameMsg").style.display = "none";
    }
    return true;
}

function emailCheck() {
    var email = document.getElementById("email").value;
    var size = email.length;
    var msg = "";

    var atSign = email.indexOf('@');
    var dotSign = email.indexOf('.', atSign);

    if (size < 6 || size > 30) {
        msg = "Email is too long or too short!"
    }
    else if (atSign == -1) {
        msg = "Email has to contain one @ sign!"
    }
    else if (atSign != email.lastIndexOf('@')) {
        msg = "Email can NOT contain more than one @ sign!"
    }
    else if (email.indexOf('.') == 0 || email.indexOf('.') == size - 1) {
        msg = "Email can Not start or and with a . sign!"
    }
    else if (dotSign - atSign <= 1) {
        msg = "The . sign need to be at least two char after the @ sign!"
    }
    else if (hasQuotes(email)) {
        msg = "Email can NOT contain ' sign or \" sign!";
    }
    else if (isValidChars(email)) {
        msg = "Email must only have valid chars!"
    }
    else if (hasHebrewChars(email)) {
        msg = "Email must not have Hebrew letters!"
    }
    if (msg != "") {
        document.getElementById("emailMsg").value = msg;
        document.getElementById("emailMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("emailMsg").value = "";
        document.getElementById("emailMsg").style.display = "none";
    }
    return true;
}
function genderCheck() {
    var gender1 = document.getElementsByName("gender");
    var genderChecked = false;
    for (var i = 0; i < gender1.length; i++) {
        if (gender1[i].checked == true) {
            genderChecked = true;
        }
    }
    if (!genderChecked) {
        document.getElementById("genderMsg").value = "Gender must be choosed!";
        document.getElementById("genderMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("genderMsg").value = "";
        document.getElementById("genderMsg").style.display = "none";
    }
    return true;
}

function hobbiesCheck() {
    var hobbies1 = document.getElementsByName("hobbies");
    var hobbiesChecked = false;
    for (var i = 0; i < hobbies1.length; i++) {
        if (hobbies1[i].checked == true) {
            hobbiesChecked = true;
        }
    }
    if (!hobbiesChecked) {
        document.getElementById("hobbiesMsg").value = "Choose at least 1 hobby!";
        document.getElementById("hobbiesMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("hobbiesMsg").value = "";
        document.getElementById("hobbiesMsg").style.display = "none";
    }
    return true;
}

function phoneCheck() {
    var phone = document.getElementById("phone").value;
    if (phone.length != 7) {
        document.getElementById("phoneMsg").value = "phone number must contain 7 digits"
        document.getElementById("phoneMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("phoneMsg").style.display = "none";
    }
    if (isNaN(phone)) {
        document.getElementById("phoneMsg").value = "phone number must contain only digits"
        document.getElementById("phoneMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("phoneMsg").style.display = "none";
    }
    return true;
}

//prefix is up

function yearBornCheck() {
    var yearBorn1 = document.getElementById("yearBorn").value;
    var msg = "";
    if (isNaN(yearBorn1)) {
        msg = "The year must be digits only!";
    }
    else if (yearBorn1 < 1900) {
        msg = "The year must be a 4 digit year after 1900!";
    }
    if (msg != "") {
        document.getElementById("yearBornMsg").value = msg;
        document.getElementById("yearBornMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("yearBornMsg").value = "";
        document.getElementById("yearBornMsg").style.display = "none";
    }
    return true;
}

function citiesCheck() {
    var cities1 = document.getElementById("cities").value;
    var msg = "";

    if (cities1 == '0') {
        msg = "You must choose a city!";
    }

    if (msg != "") {
        document.getElementById("citiesMsg").value = msg;
        document.getElementById("citiesMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("citiesMsg").value = "";
        document.getElementById("citiesMsg").style.display = "none";
    }
    return true;
}

function prefixCheck() {
    var prefix = document.getElementById("prefix").value;
    if (prefix == '0') {
        document.getElementById("prefixMsg").value = "choose prefix";
        document.getElementById("prefixMsg").style.display = "inline";
        return false;
    }
    else {
        document.getElementById("prefixMsg").style.display = "none";
    }
    return true;
}

//ADDITIONAL FUNCTIONS

//Has ' or ""
function hasQuotes(txt) {
    var singleQuote = "\'";
    var doubleQuote = '\"';

    if (txt.indexOf(singleQuote) != -1 || txt.indexOf(doubleQuote) != -1) {
        return true;
    }
    return false;
}
//Has hebrew chars
function hasHebrewChars(txt) {
    var length = txt.length;

    for (var i = 0; i < length; i++) {
        if (txt.charAt(i) >= 'א' && txt.charAt(i) <= 'ת') {
            return true;
        }
    }
    return false;
}
//find not valid chars
function isValidChars(txt) {
    var badChars = "$%^&*()-! []{}?";
    var len = txt.length;
    var i = 0;
    var pos;
    var ch;
    while (i < len) {
        ch = txt.charAt(i);
        pos = badChars.indexOf(ch);
        if (pos != -1) {
            return true;
        }
        i++;
    }
    return false;
}

//Has Capital Letter,lowercase letter, bad chars, and a digit. (if dont have return false)
function passwordConditions(txt) {
    var badChars = "$%^&*()-! []{}?";
    var len = txt.length;
    var i = 0;
    var pos;
    var ch;
    while (i < len) {
        ch = txt.charAt(i);
        pos = badChars.indexOf(ch);
        if (pos != -1) {
            return false;
        }
        i++;
    }
    return true;
}
//has capital and a lowercase letter
function hasCapitalAndLowercase(txt) {
    var hasCapital = false;
    var hasLowercase = false;
    var len = txt.length;

    for (var i = 0; i < len; i++) {
        if (txt[i] >= 'A' && txt[i] <= 'Z') {
            hasCapital = true;
        }
        if (txt[i] >= 'a' && txt[i] <= 'z') {
            hasLowercase = true;
        }
    }
    if (hasCapital && hasLowercase) {
        return true;
    }
    return false;
}
//has digit
function hasDigit(txt) {
    var len = txt.length;
    for (var i = 0; i < len; i++) {
        if (txt[i] >= '0' && txt[i] <= '9') {
            return true;
        }
    }
    return false;
}
//Equals
function equals(txt1, txt2) {
    if (txt1.length != txt2.length) {
        return false;
    }
    for (var i = 0; i < txt1.length; i++) {
        if (txt1[i] != txt2[i]) {
            return false;
        }
    }
    return true;
}

