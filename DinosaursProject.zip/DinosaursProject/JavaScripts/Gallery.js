﻿function picShow(picSrc) {
    bigPic.src = picSrc;
}